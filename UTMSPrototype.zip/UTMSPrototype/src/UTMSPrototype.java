// Abstract User class: Template for all users (Abstraction & Inheritance)
abstract class User {
    private String id;
    private String name;
    private String email;

    public User(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    // Encapsulation: private fields with validation in setters
    public String getId() { return id; }
    public void setId(String id) {
        if (id == null || id.isEmpty()) throw new IllegalArgumentException("ID cannot be empty");
        this.id = id;
    }

    public String getName() { return name; }
    public void setName(String name) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Name cannot be empty");
        this.name = name;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) {
        if (email == null || email.isEmpty()) throw new IllegalArgumentException("Email cannot be empty");
        this.email = email;
    }

    // Abstract method: must be implemented by subclasses (Polymorphism)
    public abstract void requestTransport();
}

// Student subclass
class Student extends User {
    private String studentNumber;

    public Student(String id, String name, String email, String studentNumber) {
        super(id, name, email);
        this.studentNumber = studentNumber;
    }

    public String getStudentNumber() { return studentNumber; }
    public void setStudentNumber(String studentNumber) {
        if (studentNumber == null || studentNumber.isEmpty())
            throw new IllegalArgumentException("Student number cannot be empty");
        this.studentNumber = studentNumber;
    }

    @Override
    public void requestTransport() {
        System.out.println("Student " + getName() + " requests transport. Approval required from Transport Officer.");
    }
}

// Lecturer subclass
class Lecturer extends User {
    private String staffId;

    public Lecturer(String id, String name, String email, String staffId) {
        super(id, name, email);
        this.staffId = staffId;
    }

    public String getStaffId() { return staffId; }
    public void setStaffId(String staffId) {
        if (staffId == null || staffId.isEmpty())
            throw new IllegalArgumentException("Staff ID cannot be empty");
        this.staffId = staffId;
    }

    @Override
    public void requestTransport() {
        System.out.println("Lecturer " + getName() + " requests transport. Approval automatic.");
    }
}

// TransportOfficer subclass
class TransportOfficer extends User {
    private String officerCode;

    public TransportOfficer(String id, String name, String email, String officerCode) {
        super(id, name, email);
        this.officerCode = officerCode;
    }

    public String getOfficerCode() { return officerCode; }
    public void setOfficerCode(String officerCode) {
        if (officerCode == null || officerCode.isEmpty())
            throw new IllegalArgumentException("Officer code cannot be empty");
        this.officerCode = officerCode;
    }

    @Override
    public void requestTransport() {
        System.out.println("Transport Officer " + getName() + " manages transport requests.");
    }

    // Overloaded assignDriver() methods (Method Overloading)
    public void assignDriver(String vehicleType) {
        System.out.println("Assigning driver based on vehicle type: " + vehicleType);
    }

    public void assignDriver(String vehicleType, String shiftTime) {
        System.out.println("Assigning driver for " + vehicleType + " during shift: " + shiftTime);
    }

    public void assignDriver(Driver driver) {
        System.out.println("Assigning driver " + driver.getName());
    }

    public void assignDriver(String vehicleType, Driver driver) {
        System.out.println("Assigning driver " + driver.getName() + " to vehicle type " + vehicleType);
    }
}

// Driver class with encapsulation and validation
class Driver {
    private String driverId;
    private String name;
    private String licenseNumber;

    public Driver(String driverId, String name, String licenseNumber) {
        setDriverId(driverId);
        setName(name);
        setLicenseNumber(licenseNumber);
    }

    public String getDriverId() { return driverId; }
    public void setDriverId(String driverId) {
        if (driverId == null || driverId.isEmpty()) throw new IllegalArgumentException("Driver ID cannot be empty");
        this.driverId = driverId;
    }

    public String getName() { return name; }
    public void setName(String name) {
        if (name == null || name.isEmpty()) throw new IllegalArgumentException("Driver name cannot be empty");
        this.name = name;
    }

    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) {
        if (licenseNumber == null || licenseNumber.isEmpty())
            throw new IllegalArgumentException("License number cannot be empty");
        this.licenseNumber = licenseNumber;
    }
}

// Interfaces for vehicle behaviors
interface Serviceable {
    void performService();
}

interface Trackable {
    void trackLocation();
}

interface Schedulable {
    void scheduleRoute(Route route);
}

// Route class representing a transport route
class Route {
    private String routeId;
    private String origin;
    private String destination;

    public Route(String routeId, String origin, String destination) {
        this.routeId = routeId;
        this.origin = origin;
        this.destination = destination;
    }

    public String getRouteId() { return routeId; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }

    @Override
    public String toString() {
        return origin + " to " + destination;
    }
}

// Abstract Vehicle class implementing interfaces
abstract class Vehicle implements Serviceable, Trackable, Schedulable {
    private String vehicleId;
    private String plateNumber;

    public Vehicle(String vehicleId, String plateNumber) {
        this.vehicleId = vehicleId;
        this.plateNumber = plateNumber;
    }

    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) {
        if (vehicleId == null || vehicleId.isEmpty())
            throw new IllegalArgumentException("Vehicle ID cannot be empty");
        this.vehicleId = vehicleId;
    }

    public String getPlateNumber() { return plateNumber; }
    public void setPlateNumber(String plateNumber) {
        if (plateNumber == null || plateNumber.isEmpty())
            throw new IllegalArgumentException("Plate number cannot be empty");
        this.plateNumber = plateNumber;
    }
}

// Bus class
class Bus extends Vehicle {
    private int seatingCapacity;

    public Bus(String vehicleId, String plateNumber, int seatingCapacity) {
        super(vehicleId, plateNumber);
        this.seatingCapacity = seatingCapacity;
    }

    public int getSeatingCapacity() { return seatingCapacity; }
    public void setSeatingCapacity(int seatingCapacity) {
        if (seatingCapacity <= 0) throw new IllegalArgumentException("Seating capacity must be positive");
        this.seatingCapacity = seatingCapacity;
    }

    @Override
    public void performService() {
        System.out.println("Performing service for Bus " + getPlateNumber());
    }

    @Override
    public void trackLocation() {
        System.out.println("Tracking location of Bus " + getPlateNumber());
    }

    @Override
    public void scheduleRoute(Route route) {
        System.out.println("Scheduling Bus " + getPlateNumber() + " on route " + route);
    }
}

// Van class
class Van extends Vehicle {
    private boolean refrigerated;

    public Van(String vehicleId, String plateNumber, boolean refrigerated) {
        super(vehicleId, plateNumber);
        this.refrigerated = refrigerated;
    }

    public boolean isRefrigerated() { return refrigerated; }
    public void setRefrigerated(boolean refrigerated) {
        this.refrigerated = refrigerated;
    }

    @Override
    public void performService() {
        System.out.println("Performing service for Van " + getPlateNumber());
    }

    @Override
    public void trackLocation() {
        System.out.println("Tracking location of Van " + getPlateNumber());
    }

    @Override
    public void scheduleRoute(Route route) {
        System.out.println("Scheduling Van " + getPlateNumber() + " on route " + route);
    }
}

// Main class to demonstrate functionality
public class UTMSPrototype {
    public static void main(String[] args) {
        try {
            // Create users
            User student = new Student("S001", "Alice", "alice@vu.edu", "ST123");
            User lecturer = new Lecturer("L001", "Dr. Bob", "bob@vu.edu", "LT456");
            TransportOfficer officer = new TransportOfficer("T001", "Charlie", "charlie@vu.edu", "OF789");

            // Users request transport (Polymorphism)
            student.requestTransport();
            lecturer.requestTransport();
            officer.requestTransport();

            // Create drivers
            Driver driver1 = new Driver("D001", "David", "LIC12345");
            Driver driver2 = new Driver("D002", "Eva", "LIC67890");

            // Assign drivers (Method overloading)
            officer.assignDriver("Bus");
            officer.assignDriver("Van", "Morning Shift");
            officer.assignDriver(driver1);
            officer.assignDriver("Bus", driver2);

            // Create vehicles
            Vehicle bus = new Bus("V001", "VU-1234", 40);
            Vehicle van = new Van("V002", "VU-5678", true);

            // Create routes
            Route route5 = new Route("R005", "Main Campus", "Library");
            Route route12 = new Route("R012", "Dormitories", "Lecture Halls");

            // Schedule routes and perform service
            bus.performService();
            bus.trackLocation();
            bus.scheduleRoute(route5);

            van.performService();
            van.trackLocation();
            van.scheduleRoute(route12);

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
